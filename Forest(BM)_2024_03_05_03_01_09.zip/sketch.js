var x = [];
function setup() {
  createCanvas(400, 400);
  for(var i = 0;i<200; i++)
    x[i] = random(-2000,50);
}

function draw() {
  background(0,191,255);
  
  fill(0,200,0)
  rect(0,300,400,100)
  for(var i = 0; i < x.length; i++){
    x[i] +=0.5;
    var y = (i+550) * 0.5;
    rect(x[i]-8,y,16.5,55)
    triangle(x[i],y-30,x[i]-30,y+30,x[i]+30,y+30);
    triangle(x[i],y-55,x[i]-30,y,x[i]+30,y);
  }
  fill(255,255,51)
  circle(mouseX,50,50);
  
}