let r = 0;
let g = 0;
let b = 0;
function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(220);
  
  scale(0.7);
  
  r = 255;
  g = 0;
  b = 0;
  
  for(var x = 10;x < width +70;x+=110){
    ghost(x,10);
    r = random(0,255);
    g = random(0,255);
    b = random(0,255);
    print(r,g,b);
  }
  
  r = 25;
  g = 255;
  b = 255;
  
  angleMode(DEGREES)
  rotate(90);
    ghost(200,-150);
  
  r = 255;
  g = 170;
  b = 0;
  
  ghost(310,-150);
  
  r = 255;
  g = 77;
  b = 255;
  
  ghost(420,-150);
}
        
function ghost(x,y){
  push();
  translate(x-50,y-50);
  strokeWeight(0);
  fill(r,g,b)
  arc(100, 100, 100, 100, 180, 0);
  rect(50,100,100,80);
  triangle(50, 180, 50, 200, 70, 180);
  triangle(70, 180, 90, 200, 90, 180);
  triangle(110, 180, 110, 200, 130, 180);
  triangle(130, 180, 150, 200, 150, 180);
  fill(255)
  circle(80,100,40);
  circle(120,100,40);
  fill(0,0,255)
  circle(90,100,20);
  circle(130,100,20);
  pop();
}